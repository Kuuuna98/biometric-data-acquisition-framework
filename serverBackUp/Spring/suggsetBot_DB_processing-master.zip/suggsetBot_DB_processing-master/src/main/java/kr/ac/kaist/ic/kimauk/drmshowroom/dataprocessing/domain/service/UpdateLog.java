package kr.ac.kaist.ic.kimauk.drmshowroom.dataprocessing.domain.service;

public interface UpdateLog {

    void run();
}
