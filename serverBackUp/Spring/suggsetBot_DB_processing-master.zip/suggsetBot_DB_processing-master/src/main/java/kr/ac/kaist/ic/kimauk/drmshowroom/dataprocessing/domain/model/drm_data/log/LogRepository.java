package kr.ac.kaist.ic.kimauk.drmshowroom.dataprocessing.domain.model.drm_data.log;

import org.springframework.data.repository.CrudRepository;

public interface LogRepository extends CrudRepository<Log, LogId> {

}
