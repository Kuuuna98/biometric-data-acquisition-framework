package kr.ac.kaist.ic.kimauk.drmshowroom.dataprocessing.domain.model.drm_data.history;

public enum HistoryType {
    UPLOAD_FILE_IMPORTING_DONE, UPLOAD_FILE_IMPORTING_FAILED;
}
