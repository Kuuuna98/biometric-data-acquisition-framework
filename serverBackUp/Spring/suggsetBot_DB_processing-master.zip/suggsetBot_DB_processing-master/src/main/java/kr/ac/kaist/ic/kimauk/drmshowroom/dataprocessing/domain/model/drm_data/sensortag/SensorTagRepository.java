package kr.ac.kaist.ic.kimauk.drmshowroom.dataprocessing.domain.model.drm_data.sensortag;

import org.springframework.data.repository.CrudRepository;

public interface SensorTagRepository extends CrudRepository<SensorTag, Long> {
}
