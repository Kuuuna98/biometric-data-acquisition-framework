package kr.ac.kaist.ic.kimauk.drmshowroom.dataprocessing.domain.model.main.uploads;

import org.springframework.data.repository.CrudRepository;

public interface UploadFileRepository extends CrudRepository<UploadFile, Long> {
}
